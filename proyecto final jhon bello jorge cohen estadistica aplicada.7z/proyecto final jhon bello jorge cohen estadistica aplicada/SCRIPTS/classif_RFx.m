%% 
% Script para CLASIFICACION CON REDES RANDOM FOREST
% Electiva: Procesamiento Digital de Imágenes
% 
%% Limpiar el espacio de trabajo
close all;
clc;
clear all;
%% Configuración inicial
% addpath('###');

%% Leer  parámetros de entrenamiento
matr_descrip = xlsread('Descriptores_arroz original.xlsx'); %Contiene descriptores en la tabla, xlsread carga sólo los valores numéricos de la primera pestaña
ss = size(matr_descrip); %tamaño de la matriz, en este caso de 36x6

j=1;
for i = 1:10:ss(1) %Cada 4 posiciones del vector se toman las 2 primeras muestras de cada clase (con esto se dejan 2 para la prueba)
    area(j) = matr_descrip(i,1);
    area(j+1) = matr_descrip(i+1,1);
    area(j+2) = matr_descrip(i+2,1);
    area(j+3) = matr_descrip(i+3,1);
    area(j+4) = matr_descrip(i+4,1);
    perim(j) = matr_descrip(i,2);
    perim(j+1) = matr_descrip(i+1,2);
    perim(j+2) = matr_descrip(i+2,2);
    perim(j+3) = matr_descrip(i+3,2);
    perim(j+4) = matr_descrip(i+4,2);
    orien(j) = matr_descrip(i,3);
    orien(j+1) = matr_descrip(i+1,3);
    orien(j+2) = matr_descrip(i+2,3);
    orien(j+3) = matr_descrip(i+3,3);
    orien(j+4) = matr_descrip(i+4,3);
    circ(j) = matr_descrip(i,4);
    circ(j+1) = matr_descrip(i+1,4);
    circ(j+2) = matr_descrip(i+2,4);
    circ(j+3) = matr_descrip(i+3,4);
    circ(j+4) = matr_descrip(i+4,4);
    Solidity(j) = matr_descrip(i,5);
    Solidity(j+1) = matr_descrip(i+1,5);
    Solidity(j+2) = matr_descrip(i+2,5);
    Solidity(j+3) = matr_descrip(i+3,5);
    Solidity(j+4) = matr_descrip(i+4,5);
    MajorAxisLength(j) = matr_descrip(i,6);
    MajorAxisLength(j+1) = matr_descrip(i+1,6);
    MajorAxisLength(j+2) = matr_descrip(i+2,6);
    MajorAxisLength(j+3) = matr_descrip(i+3,6);
    MajorAxisLength(j+4) = matr_descrip(i+4,6);
    MinorAxisLength(j) = matr_descrip(i,7);
    MinorAxisLength(j+1) = matr_descrip(i+1,7);
    MinorAxisLength(j+2) = matr_descrip(i+2,7);
    MinorAxisLength(j+3) = matr_descrip(i+3,7);
    MinorAxisLength(j+4) = matr_descrip(i+4,7);
     j=j+5;
end

%% Configuración y ejecución del clasificador
% 1.1 Configuración input
%X = [area; perim; orien; circ; ejeMen; ejeMay]'; %Datos de entrenamiento
X = [area; circ; MajorAxisLength; MinorAxisLength]'; %Datos de entrenamiento

% 1.2 Configuración target
T = repmat([1 2 3 4 5],5,1); %Se crea una matriz con las etiquetas posibles para las muestras (2 filas, 1 columna)
target = T(:); %Se serializa T, Vector objetivo para la clasif supervisada
%target = target';

%% Configuración y obtención del RF
disp('Configuring Random Forest...');
nArboles = 50; % número de árboles
myRF = TreeBagger(nArboles, X, target,'OOBPrediction','on'); 

%% Validación del modelo sobre muestras de prueba (las que no se usaron durante el entrenamiento)
% Se toman las 2 segundas muestras de cada clase
j=1;
for i = 6:10:ss(1) %Cada 4 posiciones del vector se toman las 2 segundas muestras de cada clase
    area(j) = matr_descrip(i,1);
    area(j+1) = matr_descrip(i+1,1);
    area(j+2) = matr_descrip(i+2,1);
    area(j+3) = matr_descrip(i+3,1);
    area(j+4) = matr_descrip(i+4,1);
    perim(j) = matr_descrip(i,2);
    perim(j+1) = matr_descrip(i+1,2);
    perim(j+2) = matr_descrip(i+2,2);
    perim(j+3) = matr_descrip(i+3,2);
    perim(j+4) = matr_descrip(i+4,2);
    orien(j) = matr_descrip(i,3);
    orien(j+1) = matr_descrip(i+1,3);
    orien(j+2) = matr_descrip(i+2,3);
    orien(j+3) = matr_descrip(i+3,3);
    orien(j+4) = matr_descrip(i+4,3);
    circ(j) = matr_descrip(i,4);
    circ(j+1) = matr_descrip(i+1,4);
    circ(j+2) = matr_descrip(i+2,4);
    circ(j+3) = matr_descrip(i+3,4);
    circ(j+4) = matr_descrip(i+4,4);
    Solidity(j) = matr_descrip(i,5);
    Solidity(j+1) = matr_descrip(i+1,5);
    Solidity(j+2) = matr_descrip(i+2,5);
    Solidity(j+3) = matr_descrip(i+3,5);
    Solidity(j+4) = matr_descrip(i+4,5);
    MajorAxisLength(j) = matr_descrip(i,6);
    MajorAxisLength(j+1) = matr_descrip(i+1,6);
    MajorAxisLength(j+2) = matr_descrip(i+2,6);
    MajorAxisLength(j+3) = matr_descrip(i+3,6);
    MajorAxisLength(j+4) = matr_descrip(i+4,6);
    MinorAxisLength(j) = matr_descrip(i,7);
    MinorAxisLength(j+1) = matr_descrip(i+1,7);
    MinorAxisLength(j+2) = matr_descrip(i+2,7);
    MinorAxisLength(j+3) = matr_descrip(i+3,7);
    MinorAxisLength(j+4) = matr_descrip(i+4,7);
    j=j+5;
end

%X_v = [area; perim; orien; circ; ejeMen; ejeMay]'; %Datos de entrenamiento %Datos de prueba
X_v = [area; circ; MajorAxisLength; MinorAxisLength]';

%Respuesta del clasificador
res = myRF.predict(X_v);

resc = str2double(res); 
outputs = resc' %outputs para presentar un vector fila con los resultados (como responde)
target' %... y compararlo con el objetivo (como debería responder)
%performance = perform(myRF, target', res)
% Evaluación del desempeño: Es mejor si se acerca a 100
eval = sum(resc==target)/length(target)*100

% save RF_model myRF % guardar modelo clasificador