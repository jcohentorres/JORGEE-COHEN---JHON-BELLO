%% Reconocimiento de patrones: 
%Etiquetado, medición de características.
%Electiva: Procesamiento de imágenes
%% Limpiando el espacio de trabajo
close all;
clc;
clear all;
%% Lectura de imagen RGB y transformación a escala de gris.
%Imagen en RGB
addpath('/MATLAB Drive/tipo de arroz original/TiposDeArroz voriginal/Jasmine');
lee_archivos = dir('/MATLAB Drive/tipo de arroz original/TiposDeArroz voriginal/Jasmine/*.jpg');
A = zeros(length(lee_archivos),7);
for k = 1:length(lee_archivos) %recorre número de archivos guardados en el directorio
    archivo = lee_archivos(k).name; %Obtiene el nombre de los archivos
    nombre='/MATLAB Drive/tipo de arroz original/TiposDeArroz voriginal/Jasmine/'; %Recore el diretorio
    I = imread(strcat(nombre,archivo));% lee la primera imagen
    figure(k), imshow(I), title('test')
    I1 = rgb2gray(I);
    thresh = graythresh(I1)
    binh = imbinarize(I1, thresh);
    %Visualización
    figure(k+5), imshow(binh), title('Binarización de la imagen')
    %% Etiquetado de la imagen
    [I_label, num] = bwlabel(binh,8);
    I_cdes = regionprops(I_label, 'all');%Calcula diferentes características para cada objeto de la imagen
    %% Medición de características
    A(k,1) = [I_cdes.Area]';
    A(k,2) = [I_cdes.Perimeter]';
    A(k,3) = [I_cdes.Orientation]';
    A(k,4) = [I_cdes.Circularity]';
    A(k,5) = [I_cdes.Solidity]';
    A(k,6) = [I_cdes.MajorAxisLength]';
    A(k,7) = [I_cdes.MinorAxisLength]';
    
% Puede seguir con mas operaciones
end

%% Descriptores, en caso de querer una tabla de excel.
Area = A(:,1);
Perimetro = A(:,2);
orientacion= A(:,3);
Circularityn=  A(:,4); 
Solidity= A(:,5);
MajorAxisLength= A(:,6);
MinorAxisLength= A(:,7);

tabla = table(Area, Perimetro, orientacion, Circularityn,Solidity,MajorAxisLength,MinorAxisLength);
tablename = 'Descriptores_Jasmine.xlsx';
writetable(tabla, tablename)