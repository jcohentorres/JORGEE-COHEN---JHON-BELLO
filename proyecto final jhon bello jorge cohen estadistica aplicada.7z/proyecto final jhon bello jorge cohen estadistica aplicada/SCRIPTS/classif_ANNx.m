%% 
% Script para CLASIFICACION CON REDES NEURONALES ARTIFICIALES
% Electiva: Procesamiento Digital de Imágenes
% 
%% Limpiar el espacio de trabajo
close all;
clc;
clear all;
%% Configuración inicial
% addpath('###');

%% Leer datos, descriptores
matr_descrip = xlsread('Descriptores_arroz original.xlsx'); %Contiene descriptores en la tabla, xlsread carga sólo los valores numéricos de la primera pestaña
ss = size(matr_descrip); %tamaño de la matriz, en este caso de 36x6

j=1;
for i = 1:10:ss(1) %Cada 4 posiciones del vector se toman las 2 primeras muestras de cada clase (con esto se dejan 2 para la prueba)
    area(j) = matr_descrip(i,1);
    area(j+1) = matr_descrip(i+1,1);
    area(j+2) = matr_descrip(i+2,1);
    area(j+3) = matr_descrip(i+3,1);
    area(j+4) = matr_descrip(i+4,1);
    perim(j) = matr_descrip(i,2);
    perim(j+1) = matr_descrip(i+1,2);
    perim(j+2) = matr_descrip(i+2,2);
    perim(j+3) = matr_descrip(i+3,2);
    perim(j+4) = matr_descrip(i+4,2);
    orien(j) = matr_descrip(i,3);
    orien(j+1) = matr_descrip(i+1,3);
    orien(j+2) = matr_descrip(i+2,3);
    orien(j+3) = matr_descrip(i+3,3);
    orien(j+4) = matr_descrip(i+4,3);
    circ(j) = matr_descrip(i,4);
    circ(j+1) = matr_descrip(i+1,4);
    circ(j+2) = matr_descrip(i+2,4);
    circ(j+3) = matr_descrip(i+3,4);
    circ(j+4) = matr_descrip(i+4,4);
    Solidity(j) = matr_descrip(i,5);
    Solidity(j+1) = matr_descrip(i+1,5);
    Solidity(j+2) = matr_descrip(i+2,5);
    Solidity(j+3) = matr_descrip(i+3,5);
    Solidity(j+4) = matr_descrip(i+4,5);
    MajorAxisLength(j) = matr_descrip(i,6);
    MajorAxisLength(j+1) = matr_descrip(i+1,6);
    MajorAxisLength(j+2) = matr_descrip(i+2,6);
    MajorAxisLength(j+3) = matr_descrip(i+3,6);
    MajorAxisLength(j+4) = matr_descrip(i+4,6);
    MinorAxisLength(j) = matr_descrip(i,7);
    MinorAxisLength(j+1) = matr_descrip(i+1,7);
    MinorAxisLength(j+2) = matr_descrip(i+2,7);
    MinorAxisLength(j+3) = matr_descrip(i+3,7);
    MinorAxisLength(j+4) = matr_descrip(i+4,7);
    j=j+5;
end

%% Configuración y ejecución del clasificador
% 1.1 Configuración input
%X = [area; perim; orien; circ; ejeMen; ejeMay]'; %Datos de entrenamiento
X = [area; circ;]'; %Datos de entrenamiento

% 1.2 Configuración target
T = repmat([1 2 3 4 5],5,1); %Se crea una matriz con las etiquetas posibles para las muestras (2 filas, 9 columnas)
target = T(:); %Se serializa T, Vector objetivo para la clasif supervisada
%target = target';

% 2: Configuración de la red neuronal
disp('Configuring Neural Network...');
trainFcn = 'trainlm';                              % Levenberg-Marquardt
hiddenLayerSize = [3 15 5];                        %if I need more layers then I should write: [10,12,...,9]
net = fitnet(hiddenLayerSize,trainFcn);
% net.layers{1}.transferFcn='logsig';                %tansig by default, but I can put another
% net.layers{2}.transferFcn='tansig';   
% net.layers{3}.transferFcn='purelin';  
% net.trainParam.goal = 0.1;
% net.trainParam.epochs = 500;
%net = init(net);                                  %initializing the network with previous configurations
% view(net)                                          % para visualizar la red final 
[net, tr] = train(net,X',target');               %training

%% Validación del modelo sobre muestras de prueba (las que no se usaron durante el entrenamiento)
% Se toman las 2 segundas muestras de cada clase
j=1;
for i = 6:10:ss(1) %Cada 4 posiciones del vector se toman las 2 segundas muestras de cada clase
    area(j) = matr_descrip(i,1);
    area(j+1) = matr_descrip(i+1,1);
    area(j+2) = matr_descrip(i+2,1);
    area(j+3) = matr_descrip(i+3,1);
    area(j+4) = matr_descrip(i+4,1);
    perim(j) = matr_descrip(i,2);
    perim(j+1) = matr_descrip(i+1,2);
    perim(j+2) = matr_descrip(i+2,2);
    perim(j+3) = matr_descrip(i+3,2);
    perim(j+4) = matr_descrip(i+4,2);
    orien(j) = matr_descrip(i,3);
    orien(j+1) = matr_descrip(i+1,3);
    orien(j+2) = matr_descrip(i+2,3);
    orien(j+3) = matr_descrip(i+3,3);
    orien(j+4) = matr_descrip(i+4,3);
    circ(j) = matr_descrip(i,4);
    circ(j+1) = matr_descrip(i+1,4);
    circ(j+2) = matr_descrip(i+2,4);
    circ(j+3) = matr_descrip(i+3,4);
    circ(j+4) = matr_descrip(i+4,4);
    Solidity(j) = matr_descrip(i,5);
    Solidity(j+1) = matr_descrip(i+1,5);
    Solidity(j+2) = matr_descrip(i+2,5);
    Solidity(j+3) = matr_descrip(i+3,5);
    Solidity(j+4) = matr_descrip(i+4,5);
    MajorAxisLength(j) = matr_descrip(i,6);
    MajorAxisLength(j+1) = matr_descrip(i+1,6);
    MajorAxisLength(j+2) = matr_descrip(i+2,6);
    MajorAxisLength(j+3) = matr_descrip(i+3,6);
    MajorAxisLength(j+4) = matr_descrip(i+4,6);
    MinorAxisLength(j) = matr_descrip(i,7);
    MinorAxisLength(j+1) = matr_descrip(i+1,7);
    MinorAxisLength(j+2) = matr_descrip(i+2,7);
    MinorAxisLength(j+3) = matr_descrip(i+3,7);
    MinorAxisLength(j+4) = matr_descrip(i+4,7);
    j=j+5;
end

%X_v = [area; perim; orien; circ; ejeMen; ejeMay]'; %Datos de entrenamiento %Datos de prueba
X_v = [area; circ;]';

%Respuesta del clasificador
outputs = round(net(X_v'));
outputs % para presentar en pantalla un vector fila con los resultados (como responde)
target' %... y compararlo con el objetivo (como debería responder)

% Evaluación del desempeño: Es mejor si se acerca a 100
%performance = perform(net, target', outputs)
eval = sum(outputs==target')/length(target)*100 

% save ANN_model net % guardar modelo clasificador